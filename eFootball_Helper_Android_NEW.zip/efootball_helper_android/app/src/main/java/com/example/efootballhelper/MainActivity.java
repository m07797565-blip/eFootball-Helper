package com.example.efootballhelper;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button ping = findViewById(R.id.btnPing);
        TextView pingText = findViewById(R.id.txtPing);
        ping.setOnClickListener(v -> {
            ping.setEnabled(false); pingText.setText("جاري فحص الاتصال...");
            executor.execute(() -> {
                long start = System.nanoTime(); int code = -1; long ms = -1;
                try {
                    URL url = new URL("https://www.google.com/generate_204");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setUseCaches(false);
                    start = System.nanoTime(); code = c.getResponseCode(); ms = (System.nanoTime()-start)/1_000_000; c.disconnect();
                } catch (Exception ignored) {}
                final long fms = ms; final int fcode = code;
                handler.post(() -> {
                    ping.setEnabled(true);
                    if (fms < 0) pingText.setText("تعذر الفحص. تأكد من الإنترنت.");
                    else {
                        String quality = fms <= 60 ? "ممتاز" : fms <= 120 ? "جيد" : fms <= 200 ? "متوسط" : "ضعيف";
                        pingText.setText(String.format(Locale.US, "زمن الاستجابة: %d ms\nالجودة: %s\nرمز الاتصال: %d", fms, quality, fcode));
                    }
                });
            });
        });

        Button calc = findViewById(R.id.btnCalc);
        EditText total = findViewById(R.id.total), targets = findViewById(R.id.targets), draws = findViewById(R.id.draws);
        TextView result = findViewById(R.id.txtResult);
        calc.setOnClickListener(v -> {
            try {
                int n = Integer.parseInt(total.getText().toString().trim());
                int k = Integer.parseInt(targets.getText().toString().trim());
                int d = Integer.parseInt(draws.getText().toString().trim());
                if (n <= 0 || k <= 0 || k > n || d < 0 || d > n) throw new Exception();
                double miss = 1.0;
                for (int i=0; i<d; i++) miss *= (double)(n-k-i)/(n-i);
                double p = 1.0 - miss;
                result.setText(String.format(Locale.US, "احتمال الحصول على واحد على الأقل من المطلوب:\n%.2f%%", p*100));
            } catch (Exception e) { result.setText("تأكد من إدخال أرقام صحيحة، وعدد السحبات لا يتجاوز عدد لاعبي البكج."); }
        });
    }
    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }
}
